
gunrock_example <- function() {
	  
  .Call("example", PACKAGE="Rgunrock")	  
}


